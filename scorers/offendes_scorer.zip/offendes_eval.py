# by fmplaza 2021

from __future__ import print_function
import re
import os
import sys

import pandas as pd
from ast import literal_eval

import sklearn.metrics as metrics
from sklearn.metrics import mean_absolute_error
import numpy as np

def evalMultiClassTask(gold_file, run_file):

  print("GOLD_FILE:", gold_file)
  print("RUN_FILE:", run_file)
  if not os.path.exists(gold_file):
    print("ERROR: run file not found")
  if not os.path.exists(run_file):
    print("ERROR: gold file not found")

  # Load GOLD file
  GOLD = pd.read_csv(gold_file, sep="\t", header=None)

  # Load DATA file
  DATA = pd.read_csv(run_file, sep="\t", header=None)
  if len(DATA.columns) == 1:
    print('Wrong run file format')
    return False

  # Merge both dataframes by id
  GOLD_DATA = pd.merge(GOLD, DATA, on=GOLD.columns[0], how='left')
  if len(DATA.columns) == 3:
    GOLD_DATA.columns = [ 'comment_id', 'label', 'conf', 'pred', 'conf_pred']
  else: 
    GOLD_DATA.columns = [ 'comment_id', 'label', 'conf', 'pred']

  #Multi-class classification
  label2id = {'NO':0, 'NOM':1, 'OFP':2, 'OFG':3}
  GOLD_DATA[1] = GOLD_DATA.apply(lambda r: label2id[r['label']], axis=1)
  GOLD_DATA[3] = GOLD_DATA.apply(lambda r: label2id[r['pred']], axis=1)

  y_true = GOLD_DATA['label'].tolist()
  y_pred = GOLD_DATA['pred'].tolist()

  #Multi-output probabilities
  y_true_conf = GOLD_DATA['conf'].tolist()
  if len(DATA.columns) == 3:
    y_pred_conf = GOLD_DATA['conf_pred'].tolist()
    mse = metrics.mean_squared_error(y_true_conf, y_pred_conf)
  else:
    mse = None

  # Calculate metrics
  label_precision = metrics.precision_score(y_true, y_pred, labels=range(len(label2id)), average=None)
  label_recall = metrics.recall_score(y_true, y_pred, labels=range(len(label2id)), average=None)
  label_f1 = metrics.f1_score(y_true, y_pred, labels=range(len(label2id)), average=None)
  macro_precision = metrics.precision_score(y_true, y_pred, average='macro')
  macro_recall = metrics.recall_score(y_true, y_pred, average='macro')
  macro_f1 = metrics.f1_score(y_true, y_pred, average='macro')
  micro_precision = metrics.precision_score(y_true, y_pred, average='micro')
  micro_recall = metrics.recall_score(y_true, y_pred, average='micro')
  micro_f1 = metrics.f1_score(y_true, y_pred, average='micro')
  weighted_precision = metrics.precision_score(y_true, y_pred, average='weighted')
  weighted_recall = metrics.recall_score(y_true, y_pred, average='weighted')
  weighted_f1 = metrics.f1_score(y_true, y_pred, average='weighted')

  return {'maf': macro_f1, 'map': macro_precision, 'mar': macro_recall, 'mif': micro_f1, 'mip': micro_precision, 'mir': micro_recall, 'avgf': weighted_f1, 'avgp': weighted_precision, 'avgr': weighted_recall, 'mse': mse}
