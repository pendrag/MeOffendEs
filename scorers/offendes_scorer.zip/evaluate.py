import os
import sys
import re

# by fmplaza 2021

# Append script path to import path to locate tass_eval
sys.path.append(os.path.realpath(__file__))

# Import evalMultiClassTask function fro meoffendes_eval module
from offendes_eval import evalMultiClassTask

#
# MAIN
#
if __name__=="__main__":
	
	input_dir = sys.argv[1]
	output_dir = sys.argv[2]

	submit_dir = os.path.join(input_dir, 'res') 
	gold_dir = os.path.join(input_dir, 'ref')
	
	if not os.path.isdir(submit_dir):
		print("%s doesn't exist" % submit_dir)
		
	try:
		dirpath, _, filenames = next(os.walk(submit_dir))
		print(dirpath, filenames)
		submit_file = os.path.join(dirpath, filenames[0])
		print("Submit file", submit_file)
	except StopIteration:
		print("Cannot find file in res directory")

	try:
		dirpath, _, filenames = next(os.walk(gold_dir))
		gold_file = os.path.join(dirpath, filenames[0])
		print("Gold file", submit_file)
	except StopIteration:
		print("Cannot find file in ref directory")


	if os.path.isdir(submit_dir) and os.path.isdir(gold_dir):
		if not os.path.exists(output_dir):
			os.makedirs(output_dir)

		output_filename = os.path.join(output_dir, 'scores.txt')              
		with open(output_filename, 'w') as output_file:
			print("Evaluating submission", submit_file, "against gold standard", gold_file)
			scores = evalMultiClassTask(gold_file, submit_file)
			output_file.write("macro_f: %f\n" % scores['maf'])
			output_file.write("macro_p: %f\n" % scores['map'])
			output_file.write("macro_r: %f\n" % scores['mar'])
			output_file.write("micro_f: %f\n" % scores['mif'])
			output_file.write("micro_p: %f\n" % scores['mip'])
			output_file.write("micro_r: %f\n" % scores['mir'])
			output_file.write("avg_f: %f\n" % scores['avgf'])
			output_file.write("avg_p: %f\n" % scores['avgp'])
			output_file.write("avg_r: %f\n" % scores['avgr'])
			output_file.write("mse: %f" % scores['mse'])