#!/usr/bin/env python
import sys
import os
import os.path

input_dir = sys.argv[1]
output_dir = sys.argv[2]

submit_dir = os.path.join(input_dir, 'res')
truth_dir = os.path.join(input_dir, 'ref')

if not os.path.isdir(submit_dir):
    print("%s doesn't exist" % submit_dir)

try:
    dirpath, _, filenames = next(os.walk(submit_dir))
    print(dirpath, filenames)
    submit_file = os.path.join(dirpath, filenames[0])
    print("Submit file", submit_file)
except StopIteration:
    print("Cannot find file in res directory")

try:
    dirpath, _, filenames = next(os.walk(truth_dir))
    gold_file = os.path.join(dirpath, filenames[0])
    print("Gold file", submit_file)
except StopIteration:
    print("Cannot find file in ref directory")


if os.path.isdir(submit_dir) and os.path.isdir(truth_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)


    output_filename = os.path.join(output_dir, 'scores.txt')
    output_file = open(output_filename, 'w')

    #truth_file = os.path.join(truth_dir, "gt.sol")
    #truth = open(truth_file).read().splitlines()
    truth = open(gold_file).read().splitlines()

    #print(truth)

    #submission_answer_file = os.path.join(submit_dir, "gt.sol")
    #submission_answer = open(submission_answer_file).read().splitlines()
    submission_answer = open(submit_file).read().splitlines()

    tp = fp = tn = fn = 0
    for i in range(len(truth)):
        if submission_answer[i] == truth[i] == '1':
            tp += 1
        if truth[i] == '1' and submission_answer[i] != truth[i]:
            fp += 1
        if submission_answer[i] == truth[i] == '0':
            tn += 1
        if truth[i] == '0' and submission_answer[i] != truth[i]:
            fn += 1


    acc1 = float(tp + tn) / float(tp + fp + tn + fn)
    precision1 = tp / float(tp + fp)
    recall1 = tp / float(tp + fn)
    f1 = 2 * ((precision1 * recall1) / (precision1 + recall1))


    #output_file.write("accuracy: %f\n" % acc1)
    #output_file.write("f1: %f\n" % f1)
    #output_file.write("recall: %f\n" % recall1)
    #output_file.write("precision: %f\n" % precision1)
    output_file.write("macro_f1: %f\n" % f1)
    output_file.write("macro_r: %f\n" % recall1)
    output_file.write("macro_p: %f\n" % precision1)
    output_file.write("micro_f: -1\n")
    output_file.write("micro_r: -1\n")
    output_file.write("micro_p: -1\n")
    output_file.write("avg_f: -1\n")
    output_file.write("avg_p: -1\n")
    output_file.write("avg_r: -1\n")
    output_file.write("mse: -1")
    output_file.close()